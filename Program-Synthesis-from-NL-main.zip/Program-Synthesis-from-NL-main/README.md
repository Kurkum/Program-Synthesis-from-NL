# Program-Synthesis-from-NL

Link do collaba z BERTem:
https://colab.research.google.com/drive/12G2nR7a4eOUEoS6KHEGZxLuTHnkN4A5u?usp=sharing

dane trzeba wrzucic lokalnie do folderu data/ w głów nym folderze repo - jest za duże na trzymanie na githubie.